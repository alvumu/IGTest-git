

## OnsetDateExt

**URL:** `http://testSK.org/StructureDefinition/onset-date-ext`
**Context:** `Condition`
**Type:** value[x] only `date`
**Purpose:** Record onset date when only the date is known.