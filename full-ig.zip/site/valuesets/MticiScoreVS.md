

# MTICIScoreValueSet (ValueSet)

**URL:** http://testSK.org/ValueSet/mtici-score-vs  
**Version:** 1.0.0 · **Status:** draft · **Experimental:** true  
**Title:** mTICI Score ValueSet  
**Description:** Codes to represent **mTICI** reperfusion grades.

## Compose
- Include **all codes** from CodeSystem `http://testSK.org/CodeSystem/mtici-score-cs`
