

# TimingMetricCodesVS (ValueSet)

**URL:** http://testSK.org/ValueSet/timing-metric-codes-vs  
**Version:** 1.0.0 · **Status:** active  
**Title:** Stroke Timing Metric Codes ValueSet  
**Description:** ValueSet for **D2N** and **D2G** metrics.

## Compose
- Include **all codes** from CodeSystem `http://testSK.org/CodeSystem/timing-metric-codes-cs`
