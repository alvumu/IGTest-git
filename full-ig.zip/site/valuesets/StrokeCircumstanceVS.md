

# StrokeCircumstanceCodesVS (ValueSet)

**URL:** http://testSK.org/ValueSet/stroke-circumstance-codes-vs  
**Version:** 1.0.0 · **Status:** active  
**Title:** Stroke Circumstance Codes ValueSet  
**Description:** Circumstance codes for **stroke onset** context.

## Compose
- Include **all codes** from CodeSystem `http://testSK.org/CodeSystem/stroke-circumstance-codes-cs`
