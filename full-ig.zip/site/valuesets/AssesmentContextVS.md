

# AssessmentContextVS (ValueSet)

**URL:** http://testSK.org/ValueSet/assessment-context-vs  
**Version:** 1.0.0 · **Status:** active  
**Title:** Assessment Context ValueSet  
**Description:** Timing/context codes for **functional scores** and assessments.

## Compose
- Include **all codes** from CodeSystem `http://testSK.org/CodeSystem/assessment-context-cs`
