

# mTICICodeVS (ValueSet)

**URL:** http://testSK.org/ValueSet/mtici-code-vs  
**Version:** 1.0.0 · **Status:** active  
**Title:** mTICI Score Codes ValueSet  
**Description:** ValueSet linking to mTICI scoring.

## Compose
- Include **all codes** from CodeSystem `http://testSK.org/CodeSystem/mtici-score-cs`
