

# ProcedureTimingContextVS (ValueSet)

**URL:** http://testSK.org/ValueSet/procedure-timing-context-vs  
**Version:** 1.0.0 · **Status:** active  
**Title:** Procedure Timing Context ValueSet  
**Description:** Timing phases for procedures **relative to encounter start**.

## Compose
- Include **all codes** from CodeSystem `http://testSK.org/CodeSystem/procedure-timing-context-cs`
