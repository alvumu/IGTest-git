

# ThrombectomyComplicationVS (ValueSet)

**URL:** http://testSK.org/ValueSet/thrombectomy-complication-vs  
**Version:** 1.0.0 · **Status:** active  
**Title:** Thrombectomy Complication ValueSet  
**Description:** SNOMED CT codes for **thrombectomy complications**.

## Includes (SNOMED CT)
- `307312008` — *Perforation of artery (disorder)*
