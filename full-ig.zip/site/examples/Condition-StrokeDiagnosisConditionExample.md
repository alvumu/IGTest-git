## StrokeDiagnosisConditionExample
- **InstanceOf:** StrokeDiagnosisConditionProfile
- **Category:** CondCat#encounter-diagnosis
- **Code:** SCT#266257000 (Transient ischemic attack)
- **Clinical Status:** ClinicalStatusCondCS#active
- **Encounter:** Reference(StrokeEncounterExample)
- **Subject:** Reference(PatientExample)