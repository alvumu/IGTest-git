

# Profiles

This section lists all **profile narrative pages** included in the guide.

> For the auto-generated summary tables of all artifacts (including StructureDefinitions), see **[Artifacts](artifacts.html)**.

{% include list-folder.html srcpath="pagecontent/profiles/" %}

