# Required Post-Acute Care Extension - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Required Post-Acute Care Extension**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-required-post-acute-care-ext.md) 
*  [Detailed Descriptions](StructureDefinition-required-post-acute-care-ext-definitions.md) 
*  [Mappings](StructureDefinition-required-post-acute-care-ext-mappings.md) 
*  [XML](StructureDefinition-required-post-acute-care-ext.profile.xml.md) 
*  [JSON](#) 

## Extension: RequiredPostAcuteCareExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-10-01 |

JSON representation of the required-post-acute-care-ext extension.

[Raw json](StructureDefinition-required-post-acute-care-ext.json) | [Download](StructureDefinition-required-post-acute-care-ext.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

