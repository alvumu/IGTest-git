#  - v0.1.0

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-ischemic-stroke-etiology-ext.md) 
*  [Detailed Descriptions](StructureDefinition-ischemic-stroke-etiology-ext-definitions.md) 
*  [Mappings](StructureDefinition-ischemic-stroke-etiology-ext-mappings.md) 
*  [XML](StructureDefinition-ischemic-stroke-etiology-ext.profile.xml.md) 
*  [JSON](StructureDefinition-ischemic-stroke-etiology-ext.profile.json.md) 

## Extension: StrokeStrokeEtiologyExt - Change History

| |
| :--- |
| Active as of 2025-10-07 |

Changes in the ischemic-stroke-etiology-ext extension.

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

