# Stroke Encounter Profile - Mappings - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Encounter Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-stroke-encounter-profile.md) 
*  [Detailed Descriptions](StructureDefinition-stroke-encounter-profile-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-stroke-encounter-profile-examples.md) 
*  [XML](StructureDefinition-stroke-encounter-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-encounter-profile.profile.json.md) 

## Resource Profile: StrokeEncounterProfile - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the stroke-encounter-profile resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

