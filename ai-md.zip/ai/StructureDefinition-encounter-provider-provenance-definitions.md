# Encounter Provider Provenance Profile (R5) - Definitions - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter Provider Provenance Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-encounter-provider-provenance.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-encounter-provider-provenance-mappings.md) 
*  [Examples](StructureDefinition-encounter-provider-provenance-examples.md) 
*  [XML](StructureDefinition-encounter-provider-provenance.profile.xml.md) 
*  [JSON](StructureDefinition-encounter-provider-provenance.profile.json.md) 

## Resource Profile: EncounterProviderProvenanceProfile - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-02 |

Definitions for the encounter-provider-provenance resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

