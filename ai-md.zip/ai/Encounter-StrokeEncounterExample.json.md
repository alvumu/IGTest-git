# StrokeEncounterExample - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeEncounterExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](Encounter-StrokeEncounterExample.md) 
*  [XML](Encounter-StrokeEncounterExample.xml.md) 
*  [JSON](#) 

## : StrokeEncounterExample - JSON Representation

[Raw json](Encounter-StrokeEncounterExample.json) | [Download](Encounter-StrokeEncounterExample.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

