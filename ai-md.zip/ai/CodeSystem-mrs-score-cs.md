# modified Rankin Scale (mRS) Score Code System - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **modified Rankin Scale (mRS) Score Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-mrs-score-cs.xml.md) 
*  [JSON](CodeSystem-mrs-score-cs.json.md) 

## CodeSystem: modified Rankin Scale (mRS) Score Code System (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/CodeSystem/mrs-score-cs | *Version*:0.1.0 |
| Active as of 2025-10-06 | *Computable Name*:MRsScoreCS |

 
Codes representing the modified Rankin Scale (mRS) score for functional outcome. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [MRsScoreVS](ValueSet-mrs-score-vs.md)

This case-insensitive code system `http://testSK.org/CodeSystem/mrs-score-cs` defines the following codes:

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

