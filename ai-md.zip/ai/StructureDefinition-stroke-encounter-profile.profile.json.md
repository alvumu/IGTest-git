# Stroke Encounter Profile - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Encounter Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-stroke-encounter-profile.md) 
*  [Detailed Descriptions](StructureDefinition-stroke-encounter-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-encounter-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-encounter-profile-examples.md) 
*  [XML](StructureDefinition-stroke-encounter-profile.profile.xml.md) 
*  [JSON](#) 

## Resource Profile: StrokeEncounterProfile - JSON Profile

| |
| :--- |
| Active as of 2025-10-03 |

JSON representation of the stroke-encounter-profile resource profile.

[Raw json](StructureDefinition-stroke-encounter-profile.json) | [Download](StructureDefinition-stroke-encounter-profile.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

