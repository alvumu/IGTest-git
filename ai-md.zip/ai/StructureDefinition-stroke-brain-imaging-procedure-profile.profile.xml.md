# Stroke Brain Imaging Procedure Profile (R5) - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Brain Imaging Procedure Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-stroke-brain-imaging-procedure-profile.md) 
*  [Detailed Descriptions](StructureDefinition-stroke-brain-imaging-procedure-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-brain-imaging-procedure-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-brain-imaging-procedure-profile-examples.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-stroke-brain-imaging-procedure-profile.profile.json.md) 

## Resource Profile: StrokeBrainImagingProcedureProfile - XML Profile

| |
| :--- |
| Active as of 2025-10-02 |

XML representation of the stroke-brain-imaging-procedure-profile resource profile.

[Raw xml](StructureDefinition-stroke-brain-imaging-procedure-profile.xml) | [Download](StructureDefinition-stroke-brain-imaging-procedure-profile.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

