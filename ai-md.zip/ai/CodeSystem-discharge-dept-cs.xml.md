# Discharge Department/Service Code System - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Discharge Department/Service Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](CodeSystem-discharge-dept-cs.md) 
*  [XML](#) 
*  [JSON](CodeSystem-discharge-dept-cs.json.md) 

## : Discharge Department/Service Code System - XML Representation

| |
| :--- |
| Active as of 2025-10-02 |

[Raw xml](CodeSystem-discharge-dept-cs.xml) | [Download](CodeSystem-discharge-dept-cs.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

