# Gender (SNOMED CT) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Gender (SNOMED CT)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-gender-snomed-ext-definitions.md) 
*  [Mappings](StructureDefinition-gender-snomed-ext-mappings.md) 
*  [XML](StructureDefinition-gender-snomed-ext.profile.xml.md) 
*  [JSON](StructureDefinition-gender-snomed-ext.profile.json.md) 

## Extension: Gender (SNOMED CT) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/gender-snomed-ext | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:GenderSNOMED |

Patient gender represented with SNOMED CT codes.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Patient with SNOMED Gender and Age (extensions)](StructureDefinition-patient-age-gender-snomed-profile.md)
* Examples for this Extension: [Patient/PatientAgeGenderSnomedExample](Patient-PatientAgeGenderSnomedExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/gender-snomed-ext)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Patient gender represented with SNOMED CT codes.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Patient gender represented with SNOMED CT codes.

 

Other representations of profile: [CSV](StructureDefinition-gender-snomed-ext.csv), [Excel](StructureDefinition-gender-snomed-ext.xlsx), [Schematron](StructureDefinition-gender-snomed-ext.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

