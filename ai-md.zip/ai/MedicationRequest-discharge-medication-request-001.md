# DischargeMedicationRequest - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DischargeMedicationRequest**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](MedicationRequest-discharge-medication-request-001.xml.md) 
*  [JSON](MedicationRequest-discharge-medication-request-001.json.md) 

## Example MedicationRequest: DischargeMedicationRequest

Profile: [Discharge Medication Request Profile](StructureDefinition-discharge-medication-request-profile.md)

**status**: Active

**intent**: Order

**category**: Community

### Medications

| | |
| :--- | :--- |
| - | **Concept** |
| * | Warfarin (substance) |

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

**encounter**: [Encounter: extension = true,ICU / Stroke Unit,false,Neurology department (environment); status = completed; type = Inpatient Encounter; actualPeriod = 2025-03-01 08:00:00+0000 --> 2025-03-10 12:00:00+0000](Encounter-StrokeEncounterExample.md)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

