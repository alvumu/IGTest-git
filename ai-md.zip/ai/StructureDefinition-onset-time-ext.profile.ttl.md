# OnsetTimeExt - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **OnsetTimeExt**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-onset-time-ext.md) 
*  [Detailed Descriptions](StructureDefinition-onset-time-ext-definitions.md) 
*  [Mappings](StructureDefinition-onset-time-ext-mappings.md) 
*  [XML](StructureDefinition-onset-time-ext.profile.xml.md) 
*  [JSON](StructureDefinition-onset-time-ext.profile.json.md) 

## Extension: OnsetTimeExt - TTL Profile

| |
| :--- |
| Draft as of 2025-10-06 |

TTL representation of the onset-time-ext extension.

[Raw ttl](StructureDefinition-onset-time-ext.ttl) | [Download](StructureDefinition-onset-time-ext.ttl)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

