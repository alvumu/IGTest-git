# Initial Care Intensity Code System - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Initial Care Intensity Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](CodeSystem-initial-care-intensity-cs.md) 
*  [XML](CodeSystem-initial-care-intensity-cs.xml.md) 
*  [JSON](CodeSystem-initial-care-intensity-cs.json.md) 

## : Initial Care Intensity Code System - TTL Representation

| |
| :--- |
| Active as of 2025-10-07 |

[Raw ttl](CodeSystem-initial-care-intensity-cs.ttl) | [Download](CodeSystem-initial-care-intensity-cs.ttl)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

