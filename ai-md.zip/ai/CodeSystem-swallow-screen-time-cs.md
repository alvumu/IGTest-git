# Swallowing Screening Timing Category Code System - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Swallowing Screening Timing Category Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-swallow-screen-time-cs.xml.md) 
*  [JSON](CodeSystem-swallow-screen-time-cs.json.md) 

## CodeSystem: Swallowing Screening Timing Category Code System (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/CodeSystem/swallow-screen-time-cs | *Version*:0.1.0 |
| Active as of 2025-10-02 | *Computable Name*:SwallowScreenTimeCS |

 
Temporal categories relative to stroke onset for swallowing screening. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [SwallowingScreeningTimingCategoryVS](ValueSet-swallowing-screening-timing-category-vs.md)

This case-insensitive code system `http://testSK.org/CodeSystem/swallow-screen-time-cs` defines the following code:

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

