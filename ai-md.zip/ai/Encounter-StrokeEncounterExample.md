# StrokeEncounterExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeEncounterExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](Encounter-StrokeEncounterExample.xml.md) 
*  [JSON](Encounter-StrokeEncounterExample.json.md) 

## Example Encounter: StrokeEncounterExample

Profile: [Stroke Encounter Profile](StructureDefinition-stroke-encounter-profile.md)

**First Hospital Extension**: true

**Initial Care Intensity Extension**: ICU / Stroke Unit

**Required Post-Acute Care Extension**: false

**Discharge Department/Service Extension**: Neurology department (environment)

**status**: Completed

**type**: Inpatient Encounter

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

**actualPeriod**: 2025-03-01 08:00:00+0000 --> 2025-03-10 12:00:00+0000

### Admissions

| | | |
| :--- | :--- | :--- |
| - | **AdmitSource** | **DischargeDisposition** |
| * | EMS from Home | Discharge to home (procedure) |

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

