# Specific Stroke Finding Observation Profile (R5) - Definitions - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Specific Stroke Finding Observation Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-specific-finding-observation-profile.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-specific-finding-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-specific-finding-observation-profile-examples.md) 
*  [XML](StructureDefinition-specific-finding-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-specific-finding-observation-profile.profile.json.md) 

## Resource Profile: SpecificFindingObservationProfile - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-06 |

Definitions for the specific-finding-observation-profile resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

