# StrokeRiskFactorConditionExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeRiskFactorConditionExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](Condition-StrokeRiskFactorConditionExample.xml.md) 
*  [JSON](Condition-StrokeRiskFactorConditionExample.json.md) 

## Example Condition: StrokeRiskFactorConditionExample

Profile: [Stroke Risk Factor Condition Profile](StructureDefinition-stroke-risk-factor-condition-profile.md)

**clinicalStatus**: Remission

**category**: Problem List Item

**code**: Ischemic stroke (disorder)

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

**encounter**: [Encounter: extension = true,ICU / Stroke Unit,false,Neurology department (environment); status = completed; type = Inpatient Encounter; actualPeriod = 2025-03-01 08:00:00+0000 --> 2025-03-10 12:00:00+0000](Encounter-StrokeEncounterExample.md)

**onset**: 2025-03-31 12:00:00+0000

**recordedDate**: 2025-03-31 12:00:00+0000

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

