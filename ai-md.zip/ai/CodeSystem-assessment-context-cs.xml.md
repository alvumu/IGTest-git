# Assessment Context Code System - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Assessment Context Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](CodeSystem-assessment-context-cs.md) 
*  [XML](#) 
*  [JSON](CodeSystem-assessment-context-cs.json.md) 

## : Assessment Context Code System - XML Representation

| |
| :--- |
| Active as of 2025-10-01 |

[Raw xml](CodeSystem-assessment-context-cs.xml) | [Download](CodeSystem-assessment-context-cs.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

