# Encounter Provider Provenance Profile (R5) - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter Provider Provenance Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-encounter-provider-provenance.md) 
*  [Detailed Descriptions](StructureDefinition-encounter-provider-provenance-definitions.md) 
*  [Mappings](StructureDefinition-encounter-provider-provenance-mappings.md) 
*  [Examples](StructureDefinition-encounter-provider-provenance-examples.md) 
*  [XML](StructureDefinition-encounter-provider-provenance.profile.xml.md) 
*  [JSON](#) 

## Resource Profile: EncounterProviderProvenanceProfile - JSON Profile

| |
| :--- |
| Active as of 2025-10-06 |

JSON representation of the encounter-provider-provenance resource profile.

[Raw json](StructureDefinition-encounter-provider-provenance.json) | [Download](StructureDefinition-encounter-provider-provenance.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

