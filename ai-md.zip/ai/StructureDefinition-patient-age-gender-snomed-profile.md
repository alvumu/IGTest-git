# Patient with SNOMED Gender and Age (extensions) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient with SNOMED Gender and Age (extensions)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-patient-age-gender-snomed-profile-definitions.md) 
*  [Mappings](StructureDefinition-patient-age-gender-snomed-profile-mappings.md) 
*  [Examples](StructureDefinition-patient-age-gender-snomed-profile-examples.md) 
*  [XML](StructureDefinition-patient-age-gender-snomed-profile.profile.xml.md) 
*  [JSON](StructureDefinition-patient-age-gender-snomed-profile.profile.json.md) 

## Resource Profile: Patient with SNOMED Gender and Age (extensions) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/patient-age-gender-snomed-profile | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:PatientAgeGenderSNOMEDProfile |

 
Profile that adds an integer age extension and a SNOMED-based gender extension. 

**Usages:**

* Examples for this Profile: [Patient/PatientAgeGenderSnomedExample](Patient-PatientAgeGenderSnomedExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/patient-age-gender-snomed-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R5/patient.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R5/patient.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 2 elements
 Prohibited: 1 element

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/patient-age-ext](StructureDefinition-patient-age-ext.md)
* [http://testSK.org/StructureDefinition/gender-snomed-ext](StructureDefinition-gender-snomed-ext.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Patient](http://hl7.org/fhir/R5/patient.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R5/patient.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 2 elements
 Prohibited: 1 element

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/patient-age-ext](StructureDefinition-patient-age-ext.md)
* [http://testSK.org/StructureDefinition/gender-snomed-ext](StructureDefinition-gender-snomed-ext.md)

 

Other representations of profile: [CSV](StructureDefinition-patient-age-gender-snomed-profile.csv), [Excel](StructureDefinition-patient-age-gender-snomed-profile.xlsx), [Schematron](StructureDefinition-patient-age-gender-snomed-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

