# Base Profile for Stroke-Related Observations - Definitions - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Base Profile for Stroke-Related Observations**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-base-stroke-observation.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-base-stroke-observation-mappings.md) 
*  [XML](StructureDefinition-base-stroke-observation.profile.xml.md) 
*  [JSON](StructureDefinition-base-stroke-observation.profile.json.md) 

## Resource Profile: BaseStrokeObservation - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-06 |

Definitions for the base-stroke-observation resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

