#  - v0.1.0

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-stroke-circumstance-observation-profile.md) 
*  [Detailed Descriptions](StructureDefinition-stroke-circumstance-observation-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-circumstance-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-circumstance-observation-profile-examples.md) 
*  [XML](StructureDefinition-stroke-circumstance-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-circumstance-observation-profile.profile.json.md) 

## Resource Profile: StrokeCircumstanceObservationProfile - Change History

| |
| :--- |
| Draft as of 2025-10-01 |

Changes in the stroke-circumstance-observation-profile resource profile.

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

