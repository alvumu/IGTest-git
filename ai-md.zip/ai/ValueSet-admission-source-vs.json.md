# Admission Sources ValueSet - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Admission Sources ValueSet**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](ValueSet-admission-source-vs.md) 
*  [XML](ValueSet-admission-source-vs.xml.md) 
*  [JSON](#) 

## : Admission Sources ValueSet - JSON Representation

| |
| :--- |
| Draft as of 2025-03-31 |

[Raw json](ValueSet-admission-source-vs.json) | [Download](ValueSet-admission-source-vs.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

