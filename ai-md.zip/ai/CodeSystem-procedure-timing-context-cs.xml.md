# Procedure Timing Context Code System - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Procedure Timing Context Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](CodeSystem-procedure-timing-context-cs.md) 
*  [XML](#) 
*  [JSON](CodeSystem-procedure-timing-context-cs.json.md) 

## : Procedure Timing Context Code System - XML Representation

| |
| :--- |
| Active as of 2025-10-07 |

[Raw xml](CodeSystem-procedure-timing-context-cs.xml) | [Download](CodeSystem-procedure-timing-context-cs.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

