# StrokeThrombolysisExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeThrombolysisExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](Procedure-StrokeThrombolysisExample.xml.md) 
*  [JSON](Procedure-StrokeThrombolysisExample.json.md) 

## Example Procedure: StrokeThrombolysisExample

Profile: [Stroke Thrombolysis Procedure Profile (R5)](StructureDefinition-stroke-mechanical-procedure-profile.md)

**Procedure Timing Context Extension**: Unknown/Not Applicable

**status**: Completed

**code**: Thrombolysis of cerebral artery by intravenous infusion (procedure)

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

**occurrence**: 2025-03-01 10:00:00+0000 --> 2025-03-01 10:30:00+0000

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

