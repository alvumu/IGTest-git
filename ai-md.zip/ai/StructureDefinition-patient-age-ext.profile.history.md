#  - v0.1.0

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-patient-age-ext.md) 
*  [Detailed Descriptions](StructureDefinition-patient-age-ext-definitions.md) 
*  [Mappings](StructureDefinition-patient-age-ext-mappings.md) 
*  [XML](StructureDefinition-patient-age-ext.profile.xml.md) 
*  [JSON](StructureDefinition-patient-age-ext.profile.json.md) 

## Extension: PatientAge - Change History

| |
| :--- |
| Draft as of 2025-10-03 |

Changes in the patient-age-ext extension.

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

