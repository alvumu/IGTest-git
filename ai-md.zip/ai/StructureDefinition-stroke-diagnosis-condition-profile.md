# Stroke Diagnosis Condition Profile - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Diagnosis Condition Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-stroke-diagnosis-condition-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-diagnosis-condition-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-diagnosis-condition-profile-examples.md) 
*  [XML](StructureDefinition-stroke-diagnosis-condition-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-diagnosis-condition-profile.profile.json.md) 

## Resource Profile: Stroke Diagnosis Condition Profile 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/stroke-diagnosis-condition-profile | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:StrokeDiagnosisConditionProfile |

 
Represents the final diagnosis of the current stroke event. 

**Usages:**

* Examples for this Profile: [Condition/StrokeDiagnosisConditionExample](Condition-StrokeDiagnosisConditionExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/stroke-diagnosis-condition-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 10 elements
 Prohibited: 1 element

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.md)
* [http://testSK.org/StructureDefinition/ischemic-stroke-etiology-ext](StructureDefinition-ischemic-stroke-etiology-ext.md)
* [http://testSK.org/StructureDefinition/onset-date-ext](StructureDefinition-onset-date-ext.md)
* [http://testSK.org/StructureDefinition/onset-time-ext](StructureDefinition-onset-time-ext.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 10 elements
 Prohibited: 1 element

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.md)
* [http://testSK.org/StructureDefinition/ischemic-stroke-etiology-ext](StructureDefinition-ischemic-stroke-etiology-ext.md)
* [http://testSK.org/StructureDefinition/onset-date-ext](StructureDefinition-onset-date-ext.md)
* [http://testSK.org/StructureDefinition/onset-time-ext](StructureDefinition-onset-time-ext.md)

 

Other representations of profile: [CSV](StructureDefinition-stroke-diagnosis-condition-profile.csv), [Excel](StructureDefinition-stroke-diagnosis-condition-profile.xlsx), [Schematron](StructureDefinition-stroke-diagnosis-condition-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

