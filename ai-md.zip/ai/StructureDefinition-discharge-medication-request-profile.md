# Discharge Medication Request Profile - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Discharge Medication Request Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-discharge-medication-request-profile-definitions.md) 
*  [Mappings](StructureDefinition-discharge-medication-request-profile-mappings.md) 
*  [Examples](StructureDefinition-discharge-medication-request-profile-examples.md) 
*  [XML](StructureDefinition-discharge-medication-request-profile.profile.xml.md) 
*  [JSON](StructureDefinition-discharge-medication-request-profile.profile.json.md) 

## Resource Profile: Discharge Medication Request Profile 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/discharge-medication-request-profile | *Version*:0.1.0 |
| Active as of 2025-10-02 | *Computable Name*:DischargeMedicationRequestProfile |

 
Represents a medication prescription made as part of the patient's discharge plan, categorized as community administration. 

**Usages:**

* Examples for this Profile: [MedicationRequest/discharge-medication-request-001](MedicationRequest-discharge-medication-request-001.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/discharge-medication-request-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationRequest](http://hl7.org/fhir/R5/medicationrequest.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationRequest](http://hl7.org/fhir/R5/medicationrequest.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 6 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [MedicationRequest](http://hl7.org/fhir/R5/medicationrequest.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationRequest](http://hl7.org/fhir/R5/medicationrequest.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 6 elements

 

Other representations of profile: [CSV](StructureDefinition-discharge-medication-request-profile.csv), [Excel](StructureDefinition-discharge-medication-request-profile.xlsx), [Schematron](StructureDefinition-discharge-medication-request-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

