# Discharge Department/Service Extension - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Discharge Department/Service Extension**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-discharge-department-service-ext-definitions.md) 
*  [Mappings](StructureDefinition-discharge-department-service-ext-mappings.md) 
*  [XML](StructureDefinition-discharge-department-service-ext.profile.xml.md) 
*  [JSON](StructureDefinition-discharge-department-service-ext.profile.json.md) 

## Extension: Discharge Department/Service Extension 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/discharge-department-service-ext | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:DischargeDepartmentServiceExtension |

Specifies the type of department or service the patient was discharged or transferred to.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Stroke Encounter Profile](StructureDefinition-stroke-encounter-profile.md)
* Examples for this Extension: [Encounter/StrokeEncounterExample](Encounter-StrokeEncounterExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/discharge-department-service-ext)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Specifies the type of department or service the patient was discharged or transferred to.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Specifies the type of department or service the patient was discharged or transferred to.

 

Other representations of profile: [CSV](StructureDefinition-discharge-department-service-ext.csv), [Excel](StructureDefinition-discharge-department-service-ext.xlsx), [Schematron](StructureDefinition-discharge-department-service-ext.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

