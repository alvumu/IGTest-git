# Specific Stroke Finding Observation Profile (R5) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Specific Stroke Finding Observation Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-specific-finding-observation-profile-definitions.md) 
*  [Mappings](StructureDefinition-specific-finding-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-specific-finding-observation-profile-examples.md) 
*  [XML](StructureDefinition-specific-finding-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-specific-finding-observation-profile.profile.json.md) 

## Resource Profile: Specific Stroke Finding Observation Profile (R5) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/specific-finding-observation-profile | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:SpecificFindingObservationProfile |

 
Profile for specific coded findings like Afib/Flutter status or mTICI score. 

**Usages:**

* Examples for this Profile: [Observation/SpecificFindingObservationExample](Observation-SpecificFindingObservationExample.md) and [Observation/SpecificFindingObservationExampleMTICI](Observation-SpecificFindingObservationExampleMTICI.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/specific-finding-observation-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

**Summary**

Mandatory: 1 element
 Must-Support: 2 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

**Summary**

Mandatory: 1 element
 Must-Support: 2 elements

 

Other representations of profile: [CSV](StructureDefinition-specific-finding-observation-profile.csv), [Excel](StructureDefinition-specific-finding-observation-profile.xlsx), [Schematron](StructureDefinition-specific-finding-observation-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

