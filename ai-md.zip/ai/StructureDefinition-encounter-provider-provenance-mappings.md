# Encounter Provider Provenance Profile (R5) - Mappings - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter Provider Provenance Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-encounter-provider-provenance.md) 
*  [Detailed Descriptions](StructureDefinition-encounter-provider-provenance-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-encounter-provider-provenance-examples.md) 
*  [XML](StructureDefinition-encounter-provider-provenance.profile.xml.md) 
*  [JSON](StructureDefinition-encounter-provider-provenance.profile.json.md) 

## Resource Profile: EncounterProviderProvenanceProfile - Mappings

| |
| :--- |
| Active as of 2025-10-06 |

Mappings for the encounter-provider-provenance resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

