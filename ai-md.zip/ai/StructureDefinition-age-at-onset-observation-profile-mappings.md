# Age at Stroke Onset Observation Profile (R5) - Mappings - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Age at Stroke Onset Observation Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-age-at-onset-observation-profile.md) 
*  [Detailed Descriptions](StructureDefinition-age-at-onset-observation-profile-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-age-at-onset-observation-profile-examples.md) 
*  [XML](StructureDefinition-age-at-onset-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-age-at-onset-observation-profile.profile.json.md) 

## Resource Profile: AgeAtOnsetObservationProfile - Mappings

| |
| :--- |
| Draft as of 2025-10-03 |

Mappings for the age-at-onset-observation-profile resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

