# Discharge Medication Request Profile - Examples - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Discharge Medication Request Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-discharge-medication-request-profile.md) 
*  [Detailed Descriptions](StructureDefinition-discharge-medication-request-profile-definitions.md) 
*  [Mappings](StructureDefinition-discharge-medication-request-profile-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-discharge-medication-request-profile.profile.xml.md) 
*  [JSON](StructureDefinition-discharge-medication-request-profile.profile.json.md) 

## Resource Profile: DischargeMedicationRequestProfile - Examples

| |
| :--- |
| Active as of 2025-10-02 |

Examples for the discharge-medication-request-profile Profile.

| |
| :--- |
| [DischargeMedicationRequest](MedicationRequest-discharge-medication-request-001.md) |

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

