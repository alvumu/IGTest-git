# mTICI Score Codes CodeSystem - Testing - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mTICI Score Codes CodeSystem**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](CodeSystem-mtici-code-cs.md) 
*  [XML](CodeSystem-mtici-code-cs.xml.md) 
*  [JSON](CodeSystem-mtici-code-cs.json.md) 

## CodeSystem: mTICI Score Codes CodeSystem - Testing (Experimental) 

| |
| :--- |
| Active as of 2025-10-01 |

### Test Plans

**No test plans are currently available for the CodeSystem.**

### Test Scripts

**No test scripts are currently available for the CodeSystem.**

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

