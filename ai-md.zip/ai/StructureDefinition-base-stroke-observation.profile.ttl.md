# Base Profile for Stroke-Related Observations - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Base Profile for Stroke-Related Observations**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-base-stroke-observation.md) 
*  [Detailed Descriptions](StructureDefinition-base-stroke-observation-definitions.md) 
*  [Mappings](StructureDefinition-base-stroke-observation-mappings.md) 
*  [XML](StructureDefinition-base-stroke-observation.profile.xml.md) 
*  [JSON](StructureDefinition-base-stroke-observation.profile.json.md) 

## Resource Profile: BaseStrokeObservation - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the base-stroke-observation resource profile.

[Raw ttl](StructureDefinition-base-stroke-observation.ttl) | [Download](StructureDefinition-base-stroke-observation.ttl)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

