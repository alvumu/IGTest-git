# Admission Sources ValueSet - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Admission Sources ValueSet**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-admission-source-vs.xml.md) 
*  [JSON](ValueSet-admission-source-vs.json.md) 

## ValueSet: Admission Sources ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/ValueSet/admission-source-vs | *Version*:0.1.0 |
| Draft as of 2025-03-31 | *Computable Name*:AdmissionSourceValueset |

 
Defines the modes of transport or pathways by which the patient arrived. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

* Include these codes as defined in [`http://snomed.info/sct`](http://www.snomed.org/) version Not Stated (use latest from terminology server)

 

### Expansion

Expansion from tx.fhir.org based on SNOMED CT International edition 01-Feb 2025

This value set contains 3 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

