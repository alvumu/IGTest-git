# Stroke Swallow Procedure Profile (R5) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Swallow Procedure Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-stroke-swallow-procedure-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-swallow-procedure-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-swallow-procedure-profile-examples.md) 
*  [XML](StructureDefinition-stroke-swallow-procedure-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-swallow-procedure-profile.profile.json.md) 

## Resource Profile: Stroke Swallow Procedure Profile (R5) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/stroke-swallow-procedure-profile | *Version*:0.1.0 |
| Active as of 2025-10-06 | *Computable Name*:StrokeSwallowProcedureProfile |

 
Procedure profile to record key stroke procedures, including status, timing, complications, reasons, and context. 

**Usages:**

* Examples for this Profile: [Procedure/StrokeSwallowingExample](Procedure-StrokeSwallowingExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/stroke-swallow-procedure-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

**Summary**

Must-Support: 4 elements

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/swallowing-screening-timing-category-ext](StructureDefinition-swallowing-screening-timing-category-ext.md)
* [http://testSK.org/StructureDefinition/procedure-timing-context-ext](StructureDefinition-procedure-timing-context-ext.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

**Summary**

Must-Support: 4 elements

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/swallowing-screening-timing-category-ext](StructureDefinition-swallowing-screening-timing-category-ext.md)
* [http://testSK.org/StructureDefinition/procedure-timing-context-ext](StructureDefinition-procedure-timing-context-ext.md)

 

Other representations of profile: [CSV](StructureDefinition-stroke-swallow-procedure-profile.csv), [Excel](StructureDefinition-stroke-swallow-procedure-profile.xlsx), [Schematron](StructureDefinition-stroke-swallow-procedure-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

