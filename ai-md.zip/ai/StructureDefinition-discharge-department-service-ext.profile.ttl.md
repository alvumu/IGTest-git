# Discharge Department/Service Extension - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Discharge Department/Service Extension**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-discharge-department-service-ext.md) 
*  [Detailed Descriptions](StructureDefinition-discharge-department-service-ext-definitions.md) 
*  [Mappings](StructureDefinition-discharge-department-service-ext-mappings.md) 
*  [XML](StructureDefinition-discharge-department-service-ext.profile.xml.md) 
*  [JSON](StructureDefinition-discharge-department-service-ext.profile.json.md) 

## Extension: DischargeDepartmentServiceExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-10-01 |

TTL representation of the discharge-department-service-ext extension.

[Raw ttl](StructureDefinition-discharge-department-service-ext.ttl) | [Download](StructureDefinition-discharge-department-service-ext.ttl)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

