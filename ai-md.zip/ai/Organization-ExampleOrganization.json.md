# ExampleOrganization - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExampleOrganization**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](Organization-ExampleOrganization.md) 
*  [XML](Organization-ExampleOrganization.xml.md) 
*  [JSON](#) 

## : ExampleOrganization - JSON Representation

[Raw json](Organization-ExampleOrganization.json) | [Download](Organization-ExampleOrganization.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

