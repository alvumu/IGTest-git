# Stroke Brain Imaging Procedure Profile (R5) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Brain Imaging Procedure Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-stroke-brain-imaging-procedure-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-brain-imaging-procedure-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-brain-imaging-procedure-profile-examples.md) 
*  [XML](StructureDefinition-stroke-brain-imaging-procedure-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-brain-imaging-procedure-profile.profile.json.md) 

## Resource Profile: Stroke Brain Imaging Procedure Profile (R5) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/stroke-brain-imaging-procedure-profile | *Version*:0.1.0 |
| Active as of 2025-10-01 | *Computable Name*:StrokeBrainImagingProcedureProfile |

 
Procedure profile to record key stroke procedures, including status, timing, complications, reasons, and context. 

**Usages:**

* Examples for this Profile: [Procedure/StrokeBrainImagingExample](Procedure-StrokeBrainImagingExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/stroke-brain-imaging-procedure-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

**Summary**

Must-Support: 4 elements

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/procedure-timing-context-ext](StructureDefinition-procedure-timing-context-ext.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Procedure](http://hl7.org/fhir/R5/procedure.html) 

**Summary**

Must-Support: 4 elements

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/procedure-timing-context-ext](StructureDefinition-procedure-timing-context-ext.md)

 

Other representations of profile: [CSV](StructureDefinition-stroke-brain-imaging-procedure-profile.csv), [Excel](StructureDefinition-stroke-brain-imaging-procedure-profile.xlsx), [Schematron](StructureDefinition-stroke-brain-imaging-procedure-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

