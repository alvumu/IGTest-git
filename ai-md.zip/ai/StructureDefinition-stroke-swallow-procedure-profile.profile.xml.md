# Stroke Swallow Procedure Profile (R5) - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Swallow Procedure Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-stroke-swallow-procedure-profile.md) 
*  [Detailed Descriptions](StructureDefinition-stroke-swallow-procedure-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-swallow-procedure-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-swallow-procedure-profile-examples.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-stroke-swallow-procedure-profile.profile.json.md) 

## Resource Profile: StrokeSwallowProcedureProfile - XML Profile

| |
| :--- |
| Active as of 2025-10-06 |

XML representation of the stroke-swallow-procedure-profile resource profile.

[Raw xml](StructureDefinition-stroke-swallow-procedure-profile.xml) | [Download](StructureDefinition-stroke-swallow-procedure-profile.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

