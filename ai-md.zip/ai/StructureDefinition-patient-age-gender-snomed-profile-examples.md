# Patient with SNOMED Gender and Age (extensions) - Examples - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient with SNOMED Gender and Age (extensions)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-patient-age-gender-snomed-profile.md) 
*  [Detailed Descriptions](StructureDefinition-patient-age-gender-snomed-profile-definitions.md) 
*  [Mappings](StructureDefinition-patient-age-gender-snomed-profile-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-patient-age-gender-snomed-profile.profile.xml.md) 
*  [JSON](StructureDefinition-patient-age-gender-snomed-profile.profile.json.md) 

## Resource Profile: PatientAgeGenderSNOMEDProfile - Examples

| |
| :--- |
| Draft as of 2025-10-03 |

Examples for the patient-age-gender-snomed-profile Profile.

| |
| :--- |
| [PatientAgeGenderSnomedExample](Patient-PatientAgeGenderSnomedExample.md) |

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

