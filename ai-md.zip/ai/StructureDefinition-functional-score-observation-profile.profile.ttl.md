# Stroke Functional Score Observation Profile (R5, Timing Ext) - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Functional Score Observation Profile (R5, Timing Ext)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-functional-score-observation-profile.md) 
*  [Detailed Descriptions](StructureDefinition-functional-score-observation-profile-definitions.md) 
*  [Mappings](StructureDefinition-functional-score-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-functional-score-observation-profile-examples.md) 
*  [XML](StructureDefinition-functional-score-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-functional-score-observation-profile.profile.json.md) 

## Resource Profile: FunctionalScoreObservationProfile - TTL Profile

| |
| :--- |
| Draft as of 2025-10-03 |

TTL representation of the functional-score-observation-profile resource profile.

[Raw ttl](StructureDefinition-functional-score-observation-profile.ttl) | [Download](StructureDefinition-functional-score-observation-profile.ttl)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

