# Stroke Vital Sign Observation Profile (R5) - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Vital Sign Observation Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-vital-sign-observation-profile.md) 
*  [Detailed Descriptions](StructureDefinition-vital-sign-observation-profile-definitions.md) 
*  [Mappings](StructureDefinition-vital-sign-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-vital-sign-observation-profile-examples.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-vital-sign-observation-profile.profile.json.md) 

## Resource Profile: VitalSignObservationProfile - XML Profile

| |
| :--- |
| Draft as of 2025-10-07 |

XML representation of the vital-sign-observation-profile resource profile.

[Raw xml](StructureDefinition-vital-sign-observation-profile.xml) | [Download](StructureDefinition-vital-sign-observation-profile.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

