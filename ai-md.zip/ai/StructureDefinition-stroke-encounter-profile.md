# Stroke Encounter Profile - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Encounter Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-stroke-encounter-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-encounter-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-encounter-profile-examples.md) 
*  [XML](StructureDefinition-stroke-encounter-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-encounter-profile.profile.json.md) 

## Resource Profile: Stroke Encounter Profile 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/stroke-encounter-profile | *Version*:0.1.0 |
| Active as of 2025-10-03 | *Computable Name*:StrokeEncounterProfile |

 
Profile for an Encounter resource representing a patient's hospital admission and stay for a stroke event, including key administrative and workflow details. 

**Usages:**

* Examples for this Profile: [Encounter/StrokeEncounterExample](Encounter-StrokeEncounterExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/stroke-encounter-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R5/encounter.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R5/encounter.html) 

**Summary**

Mandatory: 7 elements
 Must-Support: 14 elements

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/first-hospital-ext](StructureDefinition-first-hospital-ext.md)
* [http://testSK.org/StructureDefinition/initial-care-intensity-ext](StructureDefinition-initial-care-intensity-ext.md)
* [http://testSK.org/StructureDefinition/required-post-acute-care-ext](StructureDefinition-required-post-acute-care-ext.md)
* [http://testSK.org/StructureDefinition/discharge-department-service-ext](StructureDefinition-discharge-department-service-ext.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Encounter](http://hl7.org/fhir/R5/encounter.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R5/encounter.html) 

**Summary**

Mandatory: 7 elements
 Must-Support: 14 elements

**Extensions**

This structure refers to these extensions:

* [http://testSK.org/StructureDefinition/first-hospital-ext](StructureDefinition-first-hospital-ext.md)
* [http://testSK.org/StructureDefinition/initial-care-intensity-ext](StructureDefinition-initial-care-intensity-ext.md)
* [http://testSK.org/StructureDefinition/required-post-acute-care-ext](StructureDefinition-required-post-acute-care-ext.md)
* [http://testSK.org/StructureDefinition/discharge-department-service-ext](StructureDefinition-discharge-department-service-ext.md)

 

Other representations of profile: [CSV](StructureDefinition-stroke-encounter-profile.csv), [Excel](StructureDefinition-stroke-encounter-profile.xlsx), [Schematron](StructureDefinition-stroke-encounter-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

