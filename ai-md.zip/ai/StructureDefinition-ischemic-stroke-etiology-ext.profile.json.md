# StrokeStrokeEtiologyExt - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeStrokeEtiologyExt**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-ischemic-stroke-etiology-ext.md) 
*  [Detailed Descriptions](StructureDefinition-ischemic-stroke-etiology-ext-definitions.md) 
*  [Mappings](StructureDefinition-ischemic-stroke-etiology-ext-mappings.md) 
*  [XML](StructureDefinition-ischemic-stroke-etiology-ext.profile.xml.md) 
*  [JSON](#) 

## Extension: StrokeStrokeEtiologyExt - JSON Profile

| |
| :--- |
| Draft as of 2025-10-03 |

JSON representation of the ischemic-stroke-etiology-ext extension.

[Raw json](StructureDefinition-ischemic-stroke-etiology-ext.json) | [Download](StructureDefinition-ischemic-stroke-etiology-ext.json)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

