# Observation Timing Context Extension - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation Timing Context Extension**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-observation-timing-context-ext-definitions.md) 
*  [Mappings](StructureDefinition-observation-timing-context-ext-mappings.md) 
*  [XML](StructureDefinition-observation-timing-context-ext.profile.xml.md) 
*  [JSON](StructureDefinition-observation-timing-context-ext.profile.json.md) 

## Extension: Observation Timing Context Extension 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/observation-timing-context-ext | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:ObservationTimingContextExtension |

Specifies the timing context or phase (e.g., pre-stroke, admission, discharge, 3-month) in which an observation or assessment was made.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Stroke Functional Score Observation Profile (R5, Timing Ext)](StructureDefinition-functional-score-observation-profile.md)
* Examples for this Extension: [Observation/FunctionalScoreObservationExample](Observation-FunctionalScoreObservationExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/observation-timing-context-ext)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Specifies the timing context or phase (e.g., pre-stroke, admission, discharge, 3-month) in which an observation or assessment was made.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Specifies the timing context or phase (e.g., pre-stroke, admission, discharge, 3-month) in which an observation or assessment was made.

 

Other representations of profile: [CSV](StructureDefinition-observation-timing-context-ext.csv), [Excel](StructureDefinition-observation-timing-context-ext.xlsx), [Schematron](StructureDefinition-observation-timing-context-ext.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

