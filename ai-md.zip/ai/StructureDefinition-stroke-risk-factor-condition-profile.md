# Stroke Risk Factor Condition Profile - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Risk Factor Condition Profile**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-stroke-risk-factor-condition-profile-definitions.md) 
*  [Mappings](StructureDefinition-stroke-risk-factor-condition-profile-mappings.md) 
*  [Examples](StructureDefinition-stroke-risk-factor-condition-profile-examples.md) 
*  [XML](StructureDefinition-stroke-risk-factor-condition-profile.profile.xml.md) 
*  [JSON](StructureDefinition-stroke-risk-factor-condition-profile.profile.json.md) 

## Resource Profile: Stroke Risk Factor Condition Profile 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/stroke-risk-factor-condition-profile | *Version*:0.1.0 |
| Active as of 2025-10-02 | *Computable Name*:StrokeRiskFactorConditionProfile |

 
Represents a known condition or risk factor relevant to stroke. 

**Usages:**

* Examples for this Profile: [Condition/StrokeDiagnosisConditionAFib](Condition-StrokeDiagnosisConditionAFib.md), [Condition/StrokeDiagnosisConditionAFlutter](Condition-StrokeDiagnosisConditionAFlutter.md) and [Condition/StrokeRiskFactorConditionExample](Condition-StrokeRiskFactorConditionExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/stroke-risk-factor-condition-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 8 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R5/condition.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 8 elements

 

Other representations of profile: [CSV](StructureDefinition-stroke-risk-factor-condition-profile.csv), [Excel](StructureDefinition-stroke-risk-factor-condition-profile.xlsx), [Schematron](StructureDefinition-stroke-risk-factor-condition-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

