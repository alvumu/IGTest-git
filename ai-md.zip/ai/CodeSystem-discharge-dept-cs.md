# Discharge Department/Service Code System - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Discharge Department/Service Code System**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-discharge-dept-cs.xml.md) 
*  [JSON](CodeSystem-discharge-dept-cs.json.md) 

## CodeSystem: Discharge Department/Service Code System 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/CodeSystem/CodeSystem/discharge-dept-cs | *Version*:0.1.0 |
| Active as of 2025-10-03 | *Computable Name*:DischargeDeptCS |

 
Code system specifying the type of department or service the patient was discharged or transferred to. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [DischargeDeptVS](ValueSet-discharge-dept-vs.md)

This code system `http://testSK.org/CodeSystem/CodeSystem/discharge-dept-cs` defines the following codes:

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

