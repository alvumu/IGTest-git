# StrokeCarotidImagingExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeCarotidImagingExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](Procedure-StrokeCarotidImagingExample.xml.md) 
*  [JSON](Procedure-StrokeCarotidImagingExample.json.md) 

## Example Procedure: StrokeCarotidImagingExample

Profile: [Stroke Carotid Imaging Procedure Profile (R5)](StructureDefinition-stroke-carotid-imaging-procedure-profile.md)

**Procedure Timing Context Extension**: Post-Acute Phase (>=24h)

**status**: Not Done

**statusReason**: Reason Unknown

**code**: Angiography of carotid artery (procedure)

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

**occurrence**: 2025-03-01 10:00:00+0000 --> 2025-03-01 10:30:00+0000

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

