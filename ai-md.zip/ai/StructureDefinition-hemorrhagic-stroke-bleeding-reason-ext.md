# Hemorrhagic Stroke – Bleeding Reason - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Hemorrhagic Stroke – Bleeding Reason**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext-definitions.md) 
*  [Mappings](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext-mappings.md) 
*  [XML](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.profile.xml.md) 
*  [JSON](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.profile.json.md) 

## Extension: Hemorrhagic Stroke – Bleeding Reason 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:HemorrhagicStrokeBleedingReasonExt |

Captures, as a CodeableConcept bound (required) to HemorrhagicStrokeBleedingReasonVS, the identified cause of intracranial bleeding in hemorrhagic stroke (e.g., aneurysm, vascular malformation, other). Use when coding a definitive hemorrhagic stroke Condition to support analytics and decision support; do not use for non-hemorrhagic etiologies or when the cause is unknown/undetermined.

To standardize capture of the bleeding cause in hemorrhagic stroke conditions for decision support and analytics.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Stroke Diagnosis Condition Profile](StructureDefinition-stroke-diagnosis-condition-profile.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Captures, as a CodeableConcept bound (required) to HemorrhagicStrokeBleedingReasonVS, the identified cause of intracranial bleeding in hemorrhagic stroke (e.g., aneurysm, vascular malformation, other). Use when coding a definitive hemorrhagic stroke Condition to support analytics and decision support; do not use for non-hemorrhagic etiologies or when the cause is unknown/undetermined.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Captures, as a CodeableConcept bound (required) to HemorrhagicStrokeBleedingReasonVS, the identified cause of intracranial bleeding in hemorrhagic stroke (e.g., aneurysm, vascular malformation, other). Use when coding a definitive hemorrhagic stroke Condition to support analytics and decision support; do not use for non-hemorrhagic etiologies or when the cause is unknown/undetermined.

 

Other representations of profile: [CSV](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.csv), [Excel](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.xlsx), [Schematron](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

