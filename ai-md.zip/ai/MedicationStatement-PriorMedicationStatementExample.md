# PriorMedicationStatementExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PriorMedicationStatementExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](MedicationStatement-PriorMedicationStatementExample.xml.md) 
*  [JSON](MedicationStatement-PriorMedicationStatementExample.json.md) 

## Example MedicationStatement: PriorMedicationStatementExample

Profile: [Prior Medication Statement Profile (R5)](StructureDefinition-prior-medication-statement-profile.md)

**status**: Recorded

### Medications

| | |
| :--- | :--- |
| - | **Concept** |
| * | Warfarin therapy (procedure) |

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

### Reasons

| | |
| :--- | :--- |
| - | **Reference** |
| * | [Condition Transient ischemic attack (disorder)](Condition-StrokeDiagnosisConditionExample.md) |

### Adherences

| | |
| :--- | :--- |
| - | **Code** |
| * | Taking |

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

