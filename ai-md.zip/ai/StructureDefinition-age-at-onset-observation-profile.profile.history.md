#  - v0.1.0

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-age-at-onset-observation-profile.md) 
*  [Detailed Descriptions](StructureDefinition-age-at-onset-observation-profile-definitions.md) 
*  [Mappings](StructureDefinition-age-at-onset-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-age-at-onset-observation-profile-examples.md) 
*  [XML](StructureDefinition-age-at-onset-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-age-at-onset-observation-profile.profile.json.md) 

## Resource Profile: AgeAtOnsetObservationProfile - Change History

| |
| :--- |
| Draft as of 2025-10-06 |

Changes in the age-at-onset-observation-profile resource profile.

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

