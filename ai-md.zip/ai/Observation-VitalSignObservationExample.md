# VitalSignObservationExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VitalSignObservationExample**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-VitalSignObservationExample.xml.md) 
*  [JSON](Observation-VitalSignObservationExample.json.md) 

## Example Observation: VitalSignObservationExample

Profile: [Stroke Vital Sign Observation Profile (R5)](StructureDefinition-vital-sign-observation-profile.md)

**status**: Final

**category**: Vital Signs

**code**: Taking patient vital signs (procedure)

**subject**: [Anonymous Patient (no stated gender), DoB Unknown](Patient-example-patient.md)

**encounter**: [Encounter: extension = true,ICU / Stroke Unit,false,Neurology department (environment); status = completed; type = Inpatient Encounter; actualPeriod = 2025-03-01 08:00:00+0000 --> 2025-03-10 12:00:00+0000](Encounter-StrokeEncounterExample.md)

> **component****code**:Systolic blood pressure (observable entity)**value**: 120 mmHg(Details: ucum codemm[Hg] = 'mm[Hg]')

> **component****code**:Diastolic blood pressure (observable entity)**value**: 80 mmHg(Details: ucum codemm[Hg] = 'mm[Hg]')

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

