#  - v0.1.0

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-prior-medication-statement-profile.md) 
*  [Detailed Descriptions](StructureDefinition-prior-medication-statement-profile-definitions.md) 
*  [Mappings](StructureDefinition-prior-medication-statement-profile-mappings.md) 
*  [Examples](StructureDefinition-prior-medication-statement-profile-examples.md) 
*  [XML](StructureDefinition-prior-medication-statement-profile.profile.xml.md) 
*  [JSON](StructureDefinition-prior-medication-statement-profile.profile.json.md) 

## Resource Profile: PriorMedicationStatementProfile - Change History

| |
| :--- |
| Active as of 2025-10-02 |

Changes in the prior-medication-statement-profile resource profile.

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

