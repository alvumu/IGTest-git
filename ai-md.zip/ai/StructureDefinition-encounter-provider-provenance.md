# Encounter Provider Provenance Profile (R5) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter Provider Provenance Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-encounter-provider-provenance-definitions.md) 
*  [Mappings](StructureDefinition-encounter-provider-provenance-mappings.md) 
*  [Examples](StructureDefinition-encounter-provider-provenance-examples.md) 
*  [XML](StructureDefinition-encounter-provider-provenance.profile.xml.md) 
*  [JSON](StructureDefinition-encounter-provider-provenance.profile.json.md) 

## Resource Profile: Encounter Provider Provenance Profile (R5) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/encounter-provider-provenance | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:EncounterProviderProvenanceProfile |

 
R5 Profile for Provenance resource linking the healthcare provider organization (agent) to the specific Encounter resource (target). 

**Usages:**

* Examples for this Profile: [Provenance/ExampleEncounterProviderProvenance](Provenance-ExampleEncounterProviderProvenance.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/encounter-provider-provenance)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Provenance](http://hl7.org/fhir/R5/provenance.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Provenance](http://hl7.org/fhir/R5/provenance.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 5 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R5/profiling.html#slices):

* The element 1 is sliced based on the value of Provenance.agent

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Provenance](http://hl7.org/fhir/R5/provenance.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Provenance](http://hl7.org/fhir/R5/provenance.html) 

**Summary**

Mandatory: 2 elements
 Must-Support: 5 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R5/profiling.html#slices):

* The element 1 is sliced based on the value of Provenance.agent

 

Other representations of profile: [CSV](StructureDefinition-encounter-provider-provenance.csv), [Excel](StructureDefinition-encounter-provider-provenance.xlsx), [Schematron](StructureDefinition-encounter-provider-provenance.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

