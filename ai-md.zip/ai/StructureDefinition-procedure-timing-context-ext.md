# Procedure Timing Context Extension - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Procedure Timing Context Extension**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-procedure-timing-context-ext-definitions.md) 
*  [Mappings](StructureDefinition-procedure-timing-context-ext-mappings.md) 
*  [XML](StructureDefinition-procedure-timing-context-ext.profile.xml.md) 
*  [JSON](StructureDefinition-procedure-timing-context-ext.profile.json.md) 

## Extension: Procedure Timing Context Extension 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/procedure-timing-context-ext | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:ProcedureTimingContextExtension |

Specifies the timing phase (e.g., acute, post-acute) in which the procedure was performed relative to the start of the encounter.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Stroke Brain Imaging Procedure Profile (R5)](StructureDefinition-stroke-brain-imaging-procedure-profile.md), [Stroke Carotid Imaging Procedure Profile (R5)](StructureDefinition-stroke-carotid-imaging-procedure-profile.md), [Stroke Thrombolysis Procedure Profile (R5)](StructureDefinition-stroke-mechanical-procedure-profile.md) and [Stroke Swallow Procedure Profile (R5)](StructureDefinition-stroke-swallow-procedure-profile.md)
* Examples for this Extension: [Procedure/StrokeBrainImagingExample](Procedure-StrokeBrainImagingExample.md), [Procedure/StrokeCarotidImagingExample](Procedure-StrokeCarotidImagingExample.md), [Procedure/StrokeSwallowingExample](Procedure-StrokeSwallowingExample.md) and [Procedure/StrokeThrombolysisExample](Procedure-StrokeThrombolysisExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/procedure-timing-context-ext)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Specifies the timing phase (e.g., acute, post-acute) in which the procedure was performed relative to the start of the encounter.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R5/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Specifies the timing phase (e.g., acute, post-acute) in which the procedure was performed relative to the start of the encounter.

 

Other representations of profile: [CSV](StructureDefinition-procedure-timing-context-ext.csv), [Excel](StructureDefinition-procedure-timing-context-ext.xlsx), [Schematron](StructureDefinition-procedure-timing-context-ext.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

