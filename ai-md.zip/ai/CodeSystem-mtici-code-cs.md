# mTICI Score Codes CodeSystem - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mTICI Score Codes CodeSystem**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-mtici-code-cs.xml.md) 
*  [JSON](CodeSystem-mtici-code-cs.json.md) 

## CodeSystem: mTICI Score Codes CodeSystem (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/CodeSystem/mtici-code-cs | *Version*:0.1.0 |
| Active as of 2025-10-02 | *Computable Name*:mTICICodeCS |

 
Codes representing the mTICI score used to assess the degree of reperfusion after a thrombectomy procedure. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

This case-insensitive code system `http://testSK.org/CodeSystem/mtici-code-cs` defines the following code:

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

