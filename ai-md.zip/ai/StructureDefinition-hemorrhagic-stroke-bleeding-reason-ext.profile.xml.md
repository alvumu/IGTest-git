# HemorrhagicStrokeBleedingReasonExt - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HemorrhagicStrokeBleedingReasonExt**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.md) 
*  [Detailed Descriptions](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext-definitions.md) 
*  [Mappings](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.profile.json.md) 

## Extension: HemorrhagicStrokeBleedingReasonExt - XML Profile

| |
| :--- |
| Draft as of 2025-10-02 |

XML representation of the hemorrhagic-stroke-bleeding-reason-ext extension.

[Raw xml](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.xml) | [Download](StructureDefinition-hemorrhagic-stroke-bleeding-reason-ext.xml)

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

