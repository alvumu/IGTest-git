# Stroke Vital Sign Observation Profile (R5) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Vital Sign Observation Profile (R5)**

IGTest - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://alvumu.github.io/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-vital-sign-observation-profile-definitions.md) 
*  [Mappings](StructureDefinition-vital-sign-observation-profile-mappings.md) 
*  [Examples](StructureDefinition-vital-sign-observation-profile-examples.md) 
*  [XML](StructureDefinition-vital-sign-observation-profile.profile.xml.md) 
*  [JSON](StructureDefinition-vital-sign-observation-profile.profile.json.md) 

## Resource Profile: Stroke Vital Sign Observation Profile (R5) 

| | |
| :--- | :--- |
| *Official URL*:http://testSK.org/StructureDefinition/vital-sign-observation-profile | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:VitalSignObservationProfile |

 
Profile for recording key vital signs (Systolic/Diastolic BP) in stroke patients. 

**Usages:**

* Examples for this Profile: [Observation/VitalSignObservationExample](Observation-VitalSignObservationExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/SKtestIG|current/StructureDefinition/vital-sign-observation-profile)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

**Summary**

Mandatory: 1 element(1 nested mandatory element)
 Must-Support: 5 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [BaseStrokeObservation](StructureDefinition-base-stroke-observation.md) 

**Summary**

Mandatory: 1 element(1 nested mandatory element)
 Must-Support: 5 elements

 

Other representations of profile: [CSV](StructureDefinition-vital-sign-observation-profile.csv), [Excel](StructureDefinition-vital-sign-observation-profile.xlsx), [Schematron](StructureDefinition-vital-sign-observation-profile.sch) 

 IG © 2025+ [UMU](http://testSK.org/umu). Package SKtestIG#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

